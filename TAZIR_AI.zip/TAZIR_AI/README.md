
# TAZIR AI

Cyberpunk AI System Prototype

## Features
- FastAPI Backend
- React Dashboard
- Flutter Mobile Starter
- Memory Engine Prototype
- Cyberpunk UI Concept

## Run Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Run Frontend
Create a React app and replace App.js with the included file.

## Run Mobile
Copy main.dart into your Flutter project.
