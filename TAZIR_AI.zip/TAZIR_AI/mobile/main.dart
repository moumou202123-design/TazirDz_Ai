
import 'package:flutter/material.dart';

void main() {
  runApp(const TazirAIApp());
}

class TazirAIApp extends StatelessWidget {
  const TazirAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TAZIR AI',
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(
            'TAZIR AI',
            style: TextStyle(
              color: Colors.cyanAccent,
              fontSize: 36,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
