
from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime
import hashlib
import os

app = FastAPI(title="TAZIR AI Core")

MASTER_KEY = os.getenv("TAZIR_MASTER_KEY", "CHANGE_ME")

memory_store = {
    "short_term": [],
    "long_term": []
}

class PromptRequest(BaseModel):
    prompt: str
    key: str

def authenticate(key: str):
    return hashlib.sha256(key.encode()).hexdigest() == hashlib.sha256(MASTER_KEY.encode()).hexdigest()

@app.get("/")
async def root():
    return {
        "system": "TAZIR AI",
        "status": "online",
        "timestamp": str(datetime.utcnow())
    }

@app.post("/think")
async def think(data: PromptRequest):
    if not authenticate(data.key):
        return {"error": "Unauthorized"}

    analysis = hashlib.sha256(data.prompt.encode()).hexdigest()[:32]

    memory_store["short_term"].append(data.prompt)

    return {
        "analysis": analysis,
        "memory": memory_store["short_term"],
        "status": "processed"
    }
