
import React, { useState } from "react";

function App() {
  const [prompt, setPrompt] = useState("");
  const [output, setOutput] = useState(null);

  const sendPrompt = async () => {
    const response = await fetch("http://localhost:8000/think", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt,
        key: "CHANGE_ME"
      })
    });

    const data = await response.json();
    setOutput(data);
  };

  return (
    <div style={{
      background:"#050505",
      minHeight:"100vh",
      color:"#00ffee",
      padding:"40px",
      fontFamily:"Orbitron"
    }}>
      <h1>TAZIR AI — Cyberpunk Dashboard</h1>

      <input
        value={prompt}
        onChange={(e)=>setPrompt(e.target.value)}
        placeholder="Enter command..."
        style={{
          padding:"12px",
          width:"60%",
          background:"#111",
          border:"1px solid #00ffee",
          color:"#00ffee"
        }}
      />

      <button
        onClick={sendPrompt}
        style={{
          marginLeft:"10px",
          padding:"12px 20px",
          background:"#ff0033",
          border:"none",
          color:"#fff",
          cursor:"pointer"
        }}
      >
        RUN
      </button>

      {output && (
        <div style={{
          marginTop:"30px",
          border:"1px solid #00ffee",
          padding:"20px"
        }}>
          <p>Analysis: {output.analysis}</p>
          <p>Status: {output.status}</p>
        </div>
      )}
    </div>
  );
}

export default App;
